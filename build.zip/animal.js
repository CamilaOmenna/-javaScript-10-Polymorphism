"use strict";
Object.defineProperty(exports,"__esModule", { value: true });
exports.Animal = void 0;
var Animal = /** @class */ (function () {
    function Animal(nome,idade,emitirsom) {
        this.nome = nome;
        this.idade = idade;
        this.emitirSom = emitirsom;
    }
    return Animal;
}());
exports.Animal = Animal;
